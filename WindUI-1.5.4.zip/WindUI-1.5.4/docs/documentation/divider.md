# Divider

On this page
[[toc]]

## Divider
### Create Divider (for tabs)
```lua
Window:Divider()
```