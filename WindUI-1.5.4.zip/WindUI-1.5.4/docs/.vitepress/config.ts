import { defineConfig } from 'vitepress'

export default defineConfig({
    title: 'WindUI',
    description: 'Website',
})