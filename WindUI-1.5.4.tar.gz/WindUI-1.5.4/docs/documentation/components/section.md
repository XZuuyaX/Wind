# Section

On this page
[[toc]]

## Section

### Create Section
```lua
local Section = Tab:Section({ 
    Title = "Section",
    TextXAlignment = "Left",
    TextSize = 17, -- Default Size
})
```

### Edit Section Title
```lua
Section:SetTitle("New Section Title!")
```