# Paragraph

On this page
[[toc]]

## Paragraph

### Create Paragraph
```lua
local Paragraph = Tab:Paragraph({
    Title = "Paragraph",
    Desc = "Paragraph Content \nAnd second line",
})
```

### Edit Paragraph
- SetTitle()
```lua
Paragraph:SetTitle("New Title!")
```
- SetDesc()
```lua
Paragraph:SetDesc("New Description!")
```