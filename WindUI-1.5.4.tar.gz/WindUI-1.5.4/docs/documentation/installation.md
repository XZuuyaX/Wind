# Installation

1. Clone repo
```bash
git clone https://github.com/Footagesus/WindUI.git
cd WindUI
```

2. You need to install NodeJS and Lua


## Lua code
3. Run `npm run build:lua`


## Docs code
3. Run `npm run docs:build`