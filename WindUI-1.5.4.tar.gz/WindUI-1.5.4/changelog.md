# 1.5.4
### Changelog:  
- Colorpicker small remake
- Fixed BackgroundImage
- Added `Window:SetBackgroundImage()`
- Added `Window:SetToggleKey()`
- Added Notification Background Image
- Added Paragraph Colors (`Alert`)
- Added UI Expansion Indicator
- Added `:Destroy()` for elements
- Added User Icon
- Added Popup (Advanced Dialog)
- Fixed bugs